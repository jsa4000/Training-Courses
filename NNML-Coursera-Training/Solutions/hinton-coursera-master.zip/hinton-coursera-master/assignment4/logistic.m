function ret = logistic(input)
    ret = 1 ./ (1 + exp(-input));
end

